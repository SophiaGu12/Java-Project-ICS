package code.GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

import code.board.Board;
import code.board.Board3;

import javax.swing.*;




public class Menu implements ActionListener{

	private JButton buttonPlay, buttonInstruct, buttonExit;
	private JLabel titleNameLabelFirst, titleNameLabelLast;
	private Border emptyBorder = BorderFactory.createEmptyBorder();
	private Font titleFont = new Font("Times New Roman", Font.PLAIN, 90);

	public Menu() {


		JFrame frame = new JFrame("CodeNames");
		frame.setSize(800, 600);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setIconImage(new ImageIcon("2014.jpg").getImage());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		JPanel p = new JPanel();
		p.setBackground(Color.white);
		p.setPreferredSize(new Dimension(500, 500));
		p.setLayout(new BoxLayout(p, BoxLayout.PAGE_AXIS));


		//		JButton button2 = new JButton(icon);
		//		button2.setBackground(new Color(663300));
		//		button2.setBorder(emptyBorder);
		//		button2.setAlignmentX(Component.LEFT_ALIGNMENT);
		//		p.add(button2);
		//		
		//		JButton button3 = new JButton(icon);
		//		button3.setBackground(new Color(663300));
		//		button3.setBorder(emptyBorder);
		//		button3.setAlignmentX(Component.RIGHT_ALIGNMENT);
		//		p.add(button3);

		//title display
		titleNameLabelFirst = new JLabel("CODE");
		titleNameLabelFirst.setForeground(Color.blue);
		titleNameLabelFirst.setFont(titleFont);
		titleNameLabelFirst.setAlignmentX(Component.CENTER_ALIGNMENT);

		titleNameLabelLast = new JLabel("NAMES");
		titleNameLabelLast.setForeground(Color.red);
		titleNameLabelLast.setFont(titleFont);
		titleNameLabelLast.setAlignmentX(Component.CENTER_ALIGNMENT);

		p.add(titleNameLabelFirst);
		p.add(titleNameLabelLast);
		
		buttonPlay = new JButton("Play");
		buttonPlay.addActionListener(this);
		buttonPlay.setAlignmentX(Component.CENTER_ALIGNMENT);
		p.add(Box.createVerticalGlue());
		p.add(buttonPlay);

		buttonInstruct = new JButton("Instructions");
		buttonInstruct.addActionListener(this);
		buttonInstruct.setAlignmentX(Component.CENTER_ALIGNMENT);
		p.add(buttonInstruct);

		buttonExit = new JButton("Exit");
		buttonExit.addActionListener(this);
		buttonExit.setAlignmentX(Component.CENTER_ALIGNMENT);
		p.add(buttonExit);
		
		
		p.add(Box.createVerticalGlue());

		frame.add(p);
		frame.setVisible(true);


	}

	//	public static void main(String[] args) {
	//		
	//		Icon icon = new ImageIcon("Dababy.gif");
	//		Border emptyBorder = BorderFactory.createEmptyBorder();
	//		
	//		JFrame frame = new JFrame("CodeNames");
	//		frame.setSize(700, 700);
	//		frame.setLocation(5, 5);
	//		frame.setIconImage(new ImageIcon("2014.jpg").getImage());
	//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	//
	//		
	//		JPanel p = new JPanel();
	//		p.setBackground(new Color(663300));
	//		p.setPreferredSize(new Dimension(500, 500));
	//		p.setLayout(new BoxLayout(p, BoxLayout.PAGE_AXIS));
	//		
	//		
	//		JButton button2 = new JButton(icon);
	//		button2.setBackground(new Color(663300));
	//		button2.setBorder(emptyBorder);
	//		button2.setAlignmentX(Component.LEFT_ALIGNMENT);
	//		p.add(button2);
	//		
	//		JButton button3 = new JButton(icon);
	//		button3.setBackground(new Color(663300));
	//		button3.setBorder(emptyBorder);
	//		button3.setAlignmentX(Component.RIGHT_ALIGNMENT);
	//		p.add(button3);
	//		
	//		JButton button;
	//		button = new JButton("Play");
	//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
	//		p.add(Box.createVerticalGlue());
	//		p.add(button);
	//
	//		button = new JButton("Instructions");
	//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
	//		button.setBackground(new Color(0xffffff));
	//		p.add(button);
	//
	//		button = new JButton("Exit");
	//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
	//		p.add(button);
	//
	//		p.add(Box.createVerticalGlue());
	//		
	//		frame.add(p);
	//
	//		
	//		
	//		frame.setVisible(true);
	//
	//	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == buttonExit) {
			System.exit(0);
		}
		else if(e.getSource() == buttonPlay) {
			Board b = new Board();
			b.newGame();
			Board3 b3 = new Board3();
			PlayingBoard play = new PlayingBoard(b,b3);
			play.StartGUI();
		}
		else if(e.getSource() == buttonInstruct) {
			new Instruction();
		}

	}
}

