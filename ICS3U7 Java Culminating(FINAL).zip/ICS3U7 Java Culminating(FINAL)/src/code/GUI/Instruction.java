package code.GUI;

/*
 * Creates Instruction JFrame contain instructions
 * @author: Sophia Gu
 */

import java.awt.*;
import javax.swing.*;

public class Instruction {
	private JLabel instructions;
	private JFrame instructFrame;
	private JPanel instructPanel;
	
	/*
	 * Instruction Constructor
	 * @param
	 * @return None
	 */
	public Instruction() {
		// sets up Instruction frame
		instructFrame = new JFrame("CodeNames");
		instructFrame.setSize(1500, 400);
		instructFrame.setLocationRelativeTo(null);
		instructFrame.setResizable(false);
		instructFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		instructPanel = new JPanel();
		
		// instructions as JLabel using html
		instructions = new JLabel();
		instructions.setText("<html><p>"
				+ "There are 25 cards, 2-3 teams, and your objective is to uncover all the cards of your team�s colour before the other team does. <br/><br/>"
				+ "Roles:<br/>"
				+ "Spymaster - Gives clues and the number of cards they wish to uncover; correlating to that clue. They are able to see the type of cards when it is their turn to give hints.<br/>"
				+ "Operative - Picks the cards according to their team�s spymaster�s hint and count.<br/><br/>"
				+ "Rules:<br/>"
				+ "The spymaster cannot give invalid hints and counts (count has to be numbers 1-25 and hint cannot be a card name)<br/>"
				+ "When an operative picks a card and is revealed:<br/><br/>"
				+ "Inno, it will be the next team�s spymaster�s turn.<br/>"
				+ "An agent of another team�s colour, it will give a point to the team of that card colour, and it will be the next team�s turn<br/>"
				+ "An assassin, the team is eliminated. If it is a 2 team game, the other team wins. If it is a 3 team game, the two other teams continue, and you are still able to pick the eliminated team�s cards, if they remain. There are also 2 assassin cards in 3 team games.<br/>" 
				+ "An agent of your team�s colour, your team may continue. If the operatives of that team selects �count� number of team�s cards, they are allowed one extra card guess. <br/><br/>"
				+ "Play until all cards of one team are uncovered or all the assassins are uncovered.<br/> "
				+ "You may start new games in the top left corner, where it says, \"Menu\".<br/><br/> "
				+ "To see previous history of your games, refer to History.txt! </p></html>");
		
		
		// add components
		instructPanel.add(instructions);
		instructFrame.add(instructPanel);
		
		// set visible
		instructFrame.setVisible(true);
	}
}
