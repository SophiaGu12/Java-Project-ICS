Java Culminating by: Sophia Gu and Thomas Ho

This Java project is inspired by the game, "CodeNames" made by Vlaada Chvátil. 

Instructions are included in the main menu, though if still confused please refer to:
https://www.ultraboardgames.com/codenames/game-rules.php

If there is an issue with the batch file, please run game through playGame in the code.playGame package.

There is one hidden easter egg in our game, so have fun playing!