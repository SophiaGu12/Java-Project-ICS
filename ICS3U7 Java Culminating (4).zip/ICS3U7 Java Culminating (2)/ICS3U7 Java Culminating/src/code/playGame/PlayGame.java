package code.playGame;

import java.awt.event.*;
import java.time.LocalDate;
import java.awt.*;
import javax.swing.*;

import code.GUI.MainMenu;

public class PlayGame {

	/*
	 * Main method that runs title page and main menu (soon to run game)
	 * @param An array of Strings that contains arguments
	 * @return void
	 */
	public static void main(String[] args) {
		new MainMenu();
		
	}

}
