package code.GUI;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.time.*;

public class MainMenu extends JFrame{
	private JFrame titlepage;
	private JPanel titleNamePanel, startButtonPanel, titleAuthor;
	private JLabel titleNameLabelFirst, titleNameLabelLast, titleLabelAuthor;
	private JButton startButton;
	private Font titleFont = new Font("Times New Roman", Font.PLAIN, 90);
	private Font normalFont = new Font("Times New Roman", Font.PLAIN, 30);

	public MainMenu() {

		//titlepage setup
		titlepage = new JFrame();
		titlepage.setSize(800,600);
		titlepage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		titlepage.getContentPane().setBackground(Color.white);
		titlepage.setLocationRelativeTo(null);
		titlepage.setResizable(false);
		titlepage.setLayout(null);

		//title panel
		titleNamePanel = new JPanel();
		titleNamePanel.setBounds(100, 100, 600, 150);
		titleNamePanel.setBackground(Color.white);

		//title display
		titleNameLabelFirst = new JLabel("CODE");
		titleNameLabelFirst.setForeground(Color.blue);
		titleNameLabelFirst.setFont(titleFont);

		titleNameLabelLast = new JLabel("NAMES");
		titleNameLabelLast.setForeground(Color.red);
		titleNameLabelLast.setFont(titleFont);

		//button panel
		startButtonPanel = new JPanel();
		startButtonPanel.setBounds(300, 400, 200, 100);
		startButtonPanel.setBackground(Color.white);

		//button setup
		startButton = new JButton("START");
		startButton.setBackground(Color.blue);
		startButton.setForeground(Color.white);
		startButton.setFont(normalFont);

		//credit panel
		titleAuthor = new JPanel();
		titleAuthor.setBounds(300, 500, 200, 100);
		titleAuthor.setBackground(Color.white);

		//credit label
		titleLabelAuthor = new JLabel();
		titleLabelAuthor = new JLabel("Made By: Sophia Gu and Thomas Ho");
		titleAuthor.add(titleLabelAuthor);
		
		//adding components to panel
		titleNamePanel.add(titleNameLabelFirst);
		titleNamePanel.add(titleNameLabelLast);
		startButtonPanel.add(startButton);

		//adding panel to container
		titlepage.add(titleNamePanel);
		titlepage.add(startButtonPanel);
		titlepage.add(titleAuthor);

		validate();

		//set JFrame to be visible
		titlepage.setVisible(true);

		//disposes titlepage to display menu
		startButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				String count = JOptionPane.showInputDialog(null, "Enter teams (Min is 2 Max is 3): ");
				
				
				int count2 = Integer.parseInt(count);
				
				while(count2 > 3 || count2 < 2){

					count = JOptionPane.showInputDialog(null, "Invalid number of teams! Enter teams (Min is 2 Max is 3): ");
					count2 = Integer.parseInt(count);
				}

				Icon icon = new ImageIcon("middle.gif");
				String currentDate = LocalDate.now().toString();
				if (count2 == 2){ 
					String spymaster = (String)JOptionPane.showInputDialog(null, "Enter name of spymaster: ", null, JOptionPane.PLAIN_MESSAGE, icon, null, null);
					String red_team = JOptionPane.showInputDialog(null, "Enter name(s) of red team: ");
					String blue_team = JOptionPane.showInputDialog(null, "Enter name(s) of blue team: ");

					try{ 
					BufferedWriter names = new BufferedWriter(new FileWriter("History.txt", true));
					names.write("Date: " + currentDate);
					names.newLine();
					names.write("---------------------------Names----------------------------");
					names.newLine();
					names.write("Spymaster: " + spymaster);
					names.newLine();
					names.write("Red Team: " + red_team);
					names.newLine();
					names.write("Blue Team: " + blue_team);
					names.newLine();
					names.write("---------------------------Games----------------------------");
					names.newLine();
					names.write(" ");
					names.newLine();
					names.close();

					} catch(IOException ex){
						
					}

				} else if (count2 == 3){
					String spymaster = JOptionPane.showInputDialog(null, "Enter the name in spymaster: ");
					String red_team = JOptionPane.showInputDialog(null, "Enter the name(s) in red team: ");
					String blue_team = JOptionPane.showInputDialog(null, "Enter the name(s) in blue team: ");
					String green_team = JOptionPane.showInputDialog(null, "Enter the name(s) in green team: ");
					try{ 
					BufferedWriter names = new BufferedWriter(new FileWriter("History.txt", true));
					names.write("Date: " + currentDate);
					names.newLine();
					names.write("---------------------------Names---------------------------- ");
					names.newLine();
					names.write("Spymaster: " + spymaster);
					names.newLine();
					names.write("Red Team: " + red_team);
					names.newLine();
					names.write("Blue Team: " + blue_team);
					names.newLine();
					names.write("Green Team: " + green_team);
					names.newLine();
					names.write("---------------------------Games---------------------------- ");
					names.newLine();
					names.write(" ");
					names.newLine();
					names.close();

					} catch(IOException ex){
						
					}
				} 
				

					titlepage.dispose(); //disposes titlepage for main menu page
					new Menu();
			} 
		} );

	}
}

