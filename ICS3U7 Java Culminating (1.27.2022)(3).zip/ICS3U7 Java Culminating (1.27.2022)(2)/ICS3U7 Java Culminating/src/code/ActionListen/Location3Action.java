package code.ActionListen;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import code.GUI.PlayingBoard;
import code.board.Board3;
/*
 * Locations for all the cards. When a location is pressed it checks for winning state and switches
 * teams when the conditions are met. For 3 teams.
 * @author: Sophia Gu
 */
public class Location3Action implements ActionListener{

	Board3 bo;
	int num;
	PlayingBoard p;
	String clue;
	
	public Location3Action(Board3 b, int i,PlayingBoard play, String c) {
		bo = b;
		num = i;
		p = play;
		clue = c;
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		/*Code for every location, when location is pressed first makes sure it is the
		second part of teams turn, it then checks whether the person is the current teams agent or if the
		board is in a winning state. It switches teams turn if any conditions are met which require
		the turn to be switched
		 */
		if(p.getSpymaster() == 0) {
			if(!(bo.currentTeamAgent(num)) || bo.checkWin()) { // line decs count itself
				if(bo.checkWin()) {
					p.WinningTeamMsg3();	
				}
				
				bo.switchTurn();
				p.switchTurnState();
				p.UpdateLocs("","");
			}
			
			else if(bo.getCount() < 0) {
				bo.switchTurn();
				p.switchTurnState();
				p.UpdateLocs("","");
			}
			else{
				p.UpdateLocs(clue,String.valueOf(bo.getCount()) );
			}
			
			
			
		}
		
	}
}
