package code.GUI;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class MainMenu extends JFrame{
	private JFrame titlepage;
	private JPanel titleNamePanel, startButtonPanel;
	private JLabel titleNameLabelFirst, titleNameLabelLast;
	private JButton startButton;
	private Font titleFont = new Font("Times New Roman", Font.PLAIN, 90);
	private Font normalFont = new Font("Times New Roman", Font.PLAIN, 30);

	public MainMenu() {

		//titlepage setup
		titlepage = new JFrame();
		titlepage.setSize(800,600);
		titlepage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		titlepage.getContentPane().setBackground(Color.white);
		titlepage.setLocationRelativeTo(null);
		titlepage.setResizable(false);
		titlepage.setLayout(null);
		
		//title panel
		titleNamePanel = new JPanel();
		titleNamePanel.setBounds(100, 100, 600, 150);
		titleNamePanel.setBackground(Color.white);

		//title display
		titleNameLabelFirst = new JLabel("CODE");
		titleNameLabelFirst.setForeground(Color.blue);
		titleNameLabelFirst.setFont(titleFont);
		
		titleNameLabelLast = new JLabel("NAMES");
		titleNameLabelLast.setForeground(Color.red);
		titleNameLabelLast.setFont(titleFont);
		
		//button panel
		startButtonPanel = new JPanel();
		startButtonPanel.setBounds(300, 400, 200, 100);
		startButtonPanel.setBackground(Color.white);
		
		//button setup
		startButton = new JButton("START");
		startButton.setBackground(Color.blue);
		startButton.setForeground(Color.white);
		startButton.setFont(normalFont);

		//adding components to panel
		titleNamePanel.add(titleNameLabelFirst);
		titleNamePanel.add(titleNameLabelLast);
		startButtonPanel.add(startButton);

		//adding panel to container
		titlepage.add(titleNamePanel);
		titlepage.add(startButtonPanel);
		
		validate();
		
		//set JFrame to be visible
		titlepage.setVisible(true);
		
		//disposes titlepage to display menu
		startButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 
				titlepage.dispose(); //disposes titlepage for main menu page
				new Menu();
			} 
		} );

	}
}

