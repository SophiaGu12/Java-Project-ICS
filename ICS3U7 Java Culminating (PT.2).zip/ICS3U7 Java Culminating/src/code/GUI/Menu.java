package code.GUI;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.*;




public class Menu implements ActionListener{
	
	JButton button;
	Icon icon = new ImageIcon("Dababy.gif");
	Border emptyBorder = BorderFactory.createEmptyBorder();
	
	public Menu() {
		
		
		JFrame frame = new JFrame("CodeNames");
		frame.setSize(800, 600);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setIconImage(new ImageIcon("2014.jpg").getImage());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		JPanel p = new JPanel();
		p.setBackground(new Color(000000));
		p.setPreferredSize(new Dimension(500, 500));
		p.setLayout(new BoxLayout(p, BoxLayout.PAGE_AXIS));
		
		
//		JButton button2 = new JButton(icon);
//		button2.setBackground(new Color(663300));
//		button2.setBorder(emptyBorder);
//		button2.setAlignmentX(Component.LEFT_ALIGNMENT);
//		p.add(button2);
//		
//		JButton button3 = new JButton(icon);
//		button3.setBackground(new Color(663300));
//		button3.setBorder(emptyBorder);
//		button3.setAlignmentX(Component.RIGHT_ALIGNMENT);
//		p.add(button3);
	
		JButton button = new JButton();
		
		button = new JButton("Play");
		button.addActionListener(e -> System.out.println("Play"));
		button.setAlignmentX(Component.CENTER_ALIGNMENT);
		p.add(Box.createVerticalGlue());
		p.add(button);

		button = new JButton("Instructions");
		button.addActionListener(e -> System.out.println("Instructions"));
		button.setAlignmentX(Component.CENTER_ALIGNMENT);
		button.setBackground(new Color(0xffffff));
		p.add(button);

		button = new JButton("Exit");
		button.addActionListener(e -> System.out.println("Exit"));
		button.setAlignmentX(Component.CENTER_ALIGNMENT);
		p.add(button);

		p.add(Box.createVerticalGlue());
		
		frame.add(p);
		frame.setVisible(true);

		
	}
	
//	public static void main(String[] args) {
//		
//		Icon icon = new ImageIcon("Dababy.gif");
//		Border emptyBorder = BorderFactory.createEmptyBorder();
//		
//		JFrame frame = new JFrame("CodeNames");
//		frame.setSize(700, 700);
//		frame.setLocation(5, 5);
//		frame.setIconImage(new ImageIcon("2014.jpg").getImage());
//		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//
//		
//		JPanel p = new JPanel();
//		p.setBackground(new Color(663300));
//		p.setPreferredSize(new Dimension(500, 500));
//		p.setLayout(new BoxLayout(p, BoxLayout.PAGE_AXIS));
//		
//		
//		JButton button2 = new JButton(icon);
//		button2.setBackground(new Color(663300));
//		button2.setBorder(emptyBorder);
//		button2.setAlignmentX(Component.LEFT_ALIGNMENT);
//		p.add(button2);
//		
//		JButton button3 = new JButton(icon);
//		button3.setBackground(new Color(663300));
//		button3.setBorder(emptyBorder);
//		button3.setAlignmentX(Component.RIGHT_ALIGNMENT);
//		p.add(button3);
//		
//		JButton button;
//		button = new JButton("Play");
//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
//		p.add(Box.createVerticalGlue());
//		p.add(button);
//
//		button = new JButton("Instructions");
//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
//		button.setBackground(new Color(0xffffff));
//		p.add(button);
//
//		button = new JButton("Exit");
//		button.setAlignmentX(Component.CENTER_ALIGNMENT);
//		p.add(button);
//
//		p.add(Box.createVerticalGlue());
//		
//		frame.add(p);
//
//		
//		
//		frame.setVisible(true);
//
//	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == button) {
			System.out.println("Cool");
		}
		
	}
}

