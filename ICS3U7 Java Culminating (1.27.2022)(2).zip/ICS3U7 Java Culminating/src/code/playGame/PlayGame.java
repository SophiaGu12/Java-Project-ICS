package code.playGame;

import java.awt.event.*;
import java.time.LocalDate;
import java.awt.*;
import javax.swing.*;

import code.GUI.MainMenu;

public class PlayGame {

	/*
	 * Main method that runs program
	 * @param An array of Strings that contains arguments
	 * @return void
	 * @author: Sophia Gu
	 */
	public static void main(String[] args) {
		new MainMenu();
		
	}

}
