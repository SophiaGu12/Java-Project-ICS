package code.GUI;

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import java.time.*;
/*
 * Creates title page frame
 * @author: Sophia Gu (modified by Thomas Ho)
 */

public class MainMenu extends JFrame{
	private JFrame titlepage;
	private JPanel titleNamePanel, startButtonPanel, titleAuthor;
	private JLabel titleNameLabelFirst, titleNameLabelLast, titleLabelAuthor;
	private JButton startButton;
	private Font titleFont = new Font("Times New Roman", Font.PLAIN, 90);
	private Font normalFont = new Font("Times New Roman", Font.PLAIN, 30);
	
	/*
	 * MainMenu Constructor
	 * @param
	 * @return None
	 */
	
	public MainMenu() {

		//titlepage setup
		titlepage = new JFrame();
		titlepage.setSize(800,600);
		titlepage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		titlepage.getContentPane().setBackground(Color.white);
		titlepage.setLocationRelativeTo(null);
		titlepage.setResizable(false);
		titlepage.setLayout(null);

		//title panel
		titleNamePanel = new JPanel();
		titleNamePanel.setBounds(100, 100, 600, 150);
		titleNamePanel.setBackground(Color.white);

		//title display
		titleNameLabelFirst = new JLabel("CODE");
		titleNameLabelFirst.setForeground(Color.blue);
		titleNameLabelFirst.setFont(titleFont);

		titleNameLabelLast = new JLabel("NAMES");
		titleNameLabelLast.setForeground(Color.red);
		titleNameLabelLast.setFont(titleFont);

		//button panel
		startButtonPanel = new JPanel();
		startButtonPanel.setBounds(300, 400, 200, 100);
		startButtonPanel.setBackground(Color.white);

		//button setup
		startButton = new JButton("START");
		startButton.setBackground(Color.blue);
		startButton.setForeground(Color.white);
		startButton.setFont(normalFont);

		//credit panel
		titleAuthor = new JPanel();
		titleAuthor.setBounds(300, 500, 200, 100);
		titleAuthor.setBackground(Color.white);

		//credit label
		titleLabelAuthor = new JLabel();
		titleLabelAuthor = new JLabel("Made By: Sophia Gu and Thomas Ho");
		titleAuthor.add(titleLabelAuthor);
		
		//adding components to panel
		titleNamePanel.add(titleNameLabelFirst);
		titleNamePanel.add(titleNameLabelLast);
		startButtonPanel.add(startButton);

		//adding panel to container
		titlepage.add(titleNamePanel);
		titlepage.add(startButtonPanel);
		titlepage.add(titleAuthor);

		validate();

		//set JFrame to be visible
		titlepage.setVisible(true);

		/*
		 * Start button function that prompts user to enter names and team amounts
		 * @param new ActionListener()
		 * @return none
		 * @author: Thomas Ho
		 */
		startButton.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent e) { 				
				
				int count2 = 0;  //default to 2
				
				while (count2 != 2 && count2 != 3) {
					try{
						String countStr = JOptionPane.showInputDialog(null, "Enter teams (Min is 2 Max is 3): ");
						count2 = Integer.parseInt(countStr);
					}
					catch(NumberFormatException ex) {
						//cnt.setText("");
						JOptionPane.showMessageDialog(titlepage, "The number of teams needs to be 2 or 3!","Input Error",JOptionPane.ERROR_MESSAGE);
					}
				}
				
				
/*				while(count2 > 3 || count2 < 2){

					countStr = JOptionPane.showInputDialog(null, "Invalid number of teams! Enter teams (Min is 2 Max is 3): ");
					count2 = Integer.parseInt(countStr);
				}
*/
				Icon icon = new ImageIcon("middle.gif");
				String currentDate = LocalDate.now().toString();
				if (count2 == 2){ 
					String spymaster = (String)JOptionPane.showInputDialog(null, "Enter name of spymasters: ", null, JOptionPane.PLAIN_MESSAGE, icon, null, null);
					String red_team = JOptionPane.showInputDialog(null, "Enter operative(s) of red team: ");
					String blue_team = JOptionPane.showInputDialog(null, "Enter operative(s) of blue team: ");

					try{ 
					BufferedWriter names = new BufferedWriter(new FileWriter("History.txt", true));
					names.write("Date: " + currentDate);
					names.newLine();
					names.write("---------------------------Names----------------------------");
					names.newLine();
					names.write("Spymaster: " + spymaster);
					names.newLine();
					names.write("Red Team: " + red_team);
					names.newLine();
					names.write("Blue Team: " + blue_team);
					names.newLine();
					names.write("---------------------------Games----------------------------");
					names.newLine();
					names.write(" ");
					names.newLine();
					names.close();

					} catch(IOException ex){
						
					}

				} else if (count2 == 3){
					String spymaster = JOptionPane.showInputDialog(null, "Enter the names of spymasters: ");
					String red_team = JOptionPane.showInputDialog(null, "Enter the operative(s) in red team: ");
					String blue_team = JOptionPane.showInputDialog(null, "Enter the operative(s) in blue team: ");
					String green_team = JOptionPane.showInputDialog(null, "Enter the operative(s) in green team: ");
					try{ 
					BufferedWriter names = new BufferedWriter(new FileWriter("History.txt", true));
					names.write("Date: " + currentDate);
					names.newLine();
					names.write("---------------------------Names---------------------------- ");
					names.newLine();
					names.write("Spymaster: " + spymaster);
					names.newLine();
					names.write("Red Team: " + red_team);
					names.newLine();
					names.write("Blue Team: " + blue_team);
					names.newLine();
					names.write("Green Team: " + green_team);
					names.newLine();
					names.write("---------------------------Games---------------------------- ");
					names.newLine();
					names.write(" ");
					names.newLine();
					names.close();

					} catch(IOException ex){
						
					}
				} 
				

					titlepage.dispose(); //disposes titlepage for main menu page
					new Menu();
			} 
		} );

	}
}

